/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetoprovadaniel;

/**
 *
 * @author aluno
 */
public class Lasanha extends Alimento implements Congelados{
    private String sabor;
    private boolean vegan;
    
    public void especificacoes(){
        System.out.println("-----------Especificacoes Lasanha-------------");
        System.out.println("Nome: "+ this.getNome());
        System.out.println("Marca: "+ this.getMarca());
        System.out.println("Sabor: "+ this.getSabor());
        System.out.println("Vegana: "+ this.getVegan());
        System.out.println("Contem gluten: ");
        this.contemGluten();
        System.out.println("----------------------------------------------");
    }
    public void contemGluten(){
        System.out.println(true);
    }
    public void descongelar(){
        System.out.println("não descongelar, assar congelada.");
    }
    public void modoPreparo(){
        System.out.println("Preaquecer o forno em 180°C. Coloque a lasanha com embalagem sem retirar a tampa. Deixe assar por uns 40 min e dourar mais 10min.");
    }

    public String getSabor() {
        return sabor;
    }

    public void setSabor(String sabor) {
        this.sabor = sabor;
    }

    public boolean getVegan() {
        return vegan;
    }

    public void setVegan(boolean vegan) {
        this.vegan = vegan;
    }
    
    
}

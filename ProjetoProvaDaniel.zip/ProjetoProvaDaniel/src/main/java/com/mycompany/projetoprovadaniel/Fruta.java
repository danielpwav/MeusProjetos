/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetoprovadaniel;

/**
 *
 * @author aluno
 */
public class Fruta extends Alimento{
    private boolean importada;
    private float peso;
    
    public void especificacoes(){
        System.out.println("-----------Especificacoes Fruta-------------");
        System.out.println("Nome: "+ this.getNome());
        System.out.println("Marca: "+ this.getMarca());
        System.out.println("Peso: "+ this.getPeso());
        System.out.println("Importada: "+ this.getImportada());
        System.out.println("Contem gluten: ");
        this.contemGluten();
        System.out.println("----------------------------------------------");
    }
    public void contemGluten(){
        System.out.println(false);
    }

    public boolean getImportada() {
        return importada;
    }

    public void setImportada(boolean importada) {
        this.importada = importada;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetoprovadaniel;

/**
 *
 * @author aluno
 */
public class Salgadinho extends Alimento implements Congelados{
    private float peso;
    private String sabor;
    private int qtdLote;
    private boolean descongelado;
    
    
    public void especificacoes(){
        System.out.println("-----------Especificacoes Salgadinho-------------");
        System.out.println("Nome: "+ this.getNome());
        System.out.println("Marca: "+ this.getMarca());
        System.out.println("Peso: "+ this.getPeso());
        System.out.println("Sabor: "+ this.getSabor());
        System.out.println("Quantidade p/ lote: "+ this.getQtdLote());
        System.out.println("Contem gluten: ");
        this.contemGluten();
        System.out.println("-------------------------------------------------");
    }
    
    public void contemGluten(){
        if (this.getMarca() == "GlutenFree") {
            System.out.println(false);
        } else {
            System.out.println(true);
        }
    }
    
    public void descongelar(){
        this.setDescongelado(true);
        System.out.println("Salgadinhos descongelados com sucesso!");
    }
    public void modoPreparo(){
        System.out.println("Retire os salgados do freezer e deixe em temperatura ambiente por 10 minutos. Acrescente cuidadosamente os salgadinhos em oleo quente, deixe dourar o suficiente.");
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public String getSabor() {
        return sabor;
    }

    public void setSabor(String sabor) {
        this.sabor = sabor;
    }

    public int getQtdLote() {
        return qtdLote;
    }

    public void setQtdLote(int qtdLote) {
        this.qtdLote = qtdLote;
    }

    public boolean isDescongelado() {
        return descongelado;
    }

    public void setDescongelado(boolean descongelado) {
        this.descongelado = descongelado;
    }
    
}

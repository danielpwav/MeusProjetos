/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projetoprovadaniel;

/**
 *
 * @author aluno
 */
public class ProjetoProvaDaniel {

    public static void main(String[] args) {
        Alimento a[] = new Alimento[4];
        
        a[1] = new Lasanha();
        a[2] = new Salgadinho();
        a[3] = new Fruta();
        
        a[1].setNome("Seara");
        a[2].setNome("Esfirra");
        a[3].setNome("Melao");
        
        a[1].setMarca("Fit");
        a[2].setMarca("GlutenFree");
        a[3].setMarca("Seilavei");
        
        
        a[1].setPreco(15.2f);
        a[2].setPreco(30.2f);
        a[3].setPreco(5.2f);
        
        ((Lasanha)a[1]).setSabor("Carne moida");
        ((Lasanha)a[1]).setVegan(false);
        
        ((Salgadinho)a[2]).setPeso(5.2f);
        ((Salgadinho)a[2]).setSabor("Frango");
        ((Salgadinho)a[2]).setQtdLote(30);
        
        ((Fruta)a[3]).setImportada(true);
        ((Fruta)a[3]).setPeso(3.2f);
        
        ((Lasanha)a[1]).especificacoes();
        ((Salgadinho)a[2]).especificacoes();
        ((Fruta)a[3]).especificacoes();
    }
}

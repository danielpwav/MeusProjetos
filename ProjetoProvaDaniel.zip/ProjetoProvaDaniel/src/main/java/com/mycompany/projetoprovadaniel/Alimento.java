/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetoprovadaniel;

/**
 *
 * @author aluno
 */
public abstract class Alimento{
    public String nome;
    protected String marca;
    protected float preco;
    
    public void aplicarDesconto(float desconto){
        this.setPreco(this.getPreco() - desconto);
        System.out.println("Desconto aplicado! Confira o novo preco: "+ this.getPreco());
    }
    public void especificacoes(String especificacoes){
        
    }
    public void contemGluten(boolean gluten){
        System.out.println(false);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }
    
}
